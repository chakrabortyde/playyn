CREATE DATABASE  IF NOT EXISTS `playyn` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;
USE `playyn`;
-- MySQL dump 10.13  Distrib 8.0.28, for Win64 (x86_64)
--
-- Host: localhost    Database: playyn
-- ------------------------------------------------------
-- Server version	8.0.28

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `address` (
  `address_id` int NOT NULL,
  `address_line_1` varchar(300) DEFAULT NULL,
  `address_line_2` varchar(300) DEFAULT NULL,
  `city` varchar(300) DEFAULT NULL,
  `state` varchar(300) DEFAULT NULL,
  `country` varchar(300) DEFAULT NULL,
  `zipcode` int DEFAULT NULL,
  PRIMARY KEY (`address_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `address`
--

LOCK TABLES `address` WRITE;
/*!40000 ALTER TABLE `address` DISABLE KEYS */;
INSERT INTO `address` VALUES (1,'7 Middlefield Road','2','Redwood City','CA','US',94063),(2,'12 Second Avenue','4','San Mateo','CA','US',94401),(3,'24 Middle Avenue','5','Menlo Park','CA','US',94025),(4,'4 Arbor Road','7','Menlo Park','CA','US',94025),(5,'45 Middle Avenue','8','Menlo Park','CA','US',94025),(6,'7 Middlefield Road','9','Redwood City','CA','US',94063),(7,'9 Middlefield Road','8','Redwood City','CA','US',94063),(8,'2 Euclid Avenue.','34','Redwood City','CA','US',94061),(9,'456 Middlefield Road','2nd Floor','Redwood City','CA','US',94063),(10,'32 Marine Parkway.','4','Redwood City','CA','US',94065),(11,'1 Veterans Blvd.','2','Redwood City','CA','US',94063),(12,'23 Valencia Street','1','San Francisco','CA','US',94110),(13,'5 South Bernardo','6','Sunnyvale','CA','US',94087),(14,'7 South Spruce Avenue','2','South San Francisco','CA','US',94080),(15,'12 Fifth Avenue','2','Redwood City','CA','US',94063),(16,'12 West 39th Avenue','3','San Mateo','CA','US',94403),(17,'67 El Camino Real','1','Belmont','CA','US',94002),(18,'8 Avenue of the fellows','Suite 100','San Francisco','CA','US',94103);
/*!40000 ALTER TABLE `address` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album`
--

DROP TABLE IF EXISTS `album`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album` (
  `album_id` int NOT NULL AUTO_INCREMENT,
  `album_name` varchar(300) DEFAULT NULL,
  `album_release_date` datetime DEFAULT NULL,
  `album_icon` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`album_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album`
--

LOCK TABLES `album` WRITE;
/*!40000 ALTER TABLE `album` DISABLE KEYS */;
INSERT INTO `album` VALUES (1,'III','2019-05-15 00:00:00','https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png');
/*!40000 ALTER TABLE `album` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_band`
--

DROP TABLE IF EXISTS `album_band`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album_band` (
  `album_id` int NOT NULL,
  `band_id` int NOT NULL,
  PRIMARY KEY (`album_id`,`band_id`),
  KEY `band_id` (`band_id`),
  CONSTRAINT `album_band_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `album` (`album_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `album_band_ibfk_2` FOREIGN KEY (`band_id`) REFERENCES `band` (`band_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_band`
--

LOCK TABLES `album_band` WRITE;
/*!40000 ALTER TABLE `album_band` DISABLE KEYS */;
INSERT INTO `album_band` VALUES (1,1);
/*!40000 ALTER TABLE `album_band` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_market`
--

DROP TABLE IF EXISTS `album_market`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album_market` (
  `album_id` int NOT NULL,
  `market_id` int NOT NULL,
  PRIMARY KEY (`album_id`,`market_id`),
  KEY `market_id` (`market_id`),
  CONSTRAINT `album_market_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `album` (`album_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `album_market_ibfk_2` FOREIGN KEY (`market_id`) REFERENCES `available_market` (`market_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_market`
--

LOCK TABLES `album_market` WRITE;
/*!40000 ALTER TABLE `album_market` DISABLE KEYS */;
INSERT INTO `album_market` VALUES (1,1),(1,2),(1,3);
/*!40000 ALTER TABLE `album_market` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `album_track`
--

DROP TABLE IF EXISTS `album_track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `album_track` (
  `album_id` int NOT NULL,
  `track_id` int NOT NULL,
  PRIMARY KEY (`album_id`,`track_id`),
  KEY `track_id` (`track_id`),
  CONSTRAINT `album_track_ibfk_1` FOREIGN KEY (`album_id`) REFERENCES `album` (`album_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `album_track_ibfk_2` FOREIGN KEY (`track_id`) REFERENCES `track` (`track_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `album_track`
--

LOCK TABLES `album_track` WRITE;
/*!40000 ALTER TABLE `album_track` DISABLE KEYS */;
INSERT INTO `album_track` VALUES (1,1),(1,2),(1,3),(1,4),(1,5),(1,6),(1,7),(1,8),(1,9),(1,10);
/*!40000 ALTER TABLE `album_track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist`
--

DROP TABLE IF EXISTS `artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist` (
  `artist_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(300) DEFAULT NULL,
  `last_name` varchar(300) DEFAULT NULL,
  `gender` varchar(300) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address_id` int DEFAULT NULL,
  `phone_no` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `email_address` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`artist_id`),
  UNIQUE KEY `phone_no` (`phone_no`),
  UNIQUE KEY `email_address` (`email_address`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `artist_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist`
--

LOCK TABLES `artist` WRITE;
/*!40000 ALTER TABLE `artist` DISABLE KEYS */;
INSERT INTO `artist` VALUES (1,'Wesley','Schultz','Male','1982-12-30',1,'+16458619589','thelumineers','schultz.we@thelumineers.com'),(2,'Neyla','Pekarek','Female','1986-09-04',11,'+13679541244','thelumineers','pekarek.ne@thelumineers.com'),(3,'Fraites','Jeremiah','Male','1986-01-17',5,'+16985478965','thelumineers','jeremiah.fr@thelumineers.com'),(4,'Maxwell','Hughes','Male','1984-02-04',7,'+13465798412','thelumineers','hughes.ma@thelumineers.com'),(5,'Ben','Wahamaki','Male','1988-05-06',6,'+12134659787','thelumineers','wahamaki.ben@thelumineers.com');
/*!40000 ALTER TABLE `artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `artist_proficiency`
--

DROP TABLE IF EXISTS `artist_proficiency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `artist_proficiency` (
  `artist_id` int NOT NULL,
  `proficiency_id` int NOT NULL,
  PRIMARY KEY (`artist_id`,`proficiency_id`),
  KEY `proficiency_id` (`proficiency_id`),
  CONSTRAINT `artist_proficiency_ibfk_1` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `artist_proficiency_ibfk_2` FOREIGN KEY (`proficiency_id`) REFERENCES `proficiency` (`proficiency_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `artist_proficiency`
--

LOCK TABLES `artist_proficiency` WRITE;
/*!40000 ALTER TABLE `artist_proficiency` DISABLE KEYS */;
INSERT INTO `artist_proficiency` VALUES (1,1),(3,1),(4,2),(5,4),(1,5),(2,6),(3,8);
/*!40000 ALTER TABLE `artist_proficiency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `audio_features`
--

DROP TABLE IF EXISTS `audio_features`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `audio_features` (
  `track_id` int DEFAULT NULL,
  `acousticness` float DEFAULT NULL,
  `danceability` float DEFAULT NULL,
  `energy` float DEFAULT NULL,
  `instrumentalness` float DEFAULT NULL,
  `keynote` float DEFAULT NULL,
  `liveness` float DEFAULT NULL,
  `loudness` float DEFAULT NULL,
  `scale` float DEFAULT NULL,
  `speechiness` float DEFAULT NULL,
  `tempo` float DEFAULT NULL,
  `valence` float DEFAULT NULL,
  UNIQUE KEY `track_id` (`track_id`),
  CONSTRAINT `audio_features_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `track` (`track_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `audio_features`
--

LOCK TABLES `audio_features` WRITE;
/*!40000 ALTER TABLE `audio_features` DISABLE KEYS */;
INSERT INTO `audio_features` VALUES (1,0.6,0.72,0.78,0.63,0.25,0.56,0.91,0.34,0.72,0.51,0.34),(2,0.56,0.55,0.17,0.65,0.22,0.94,0.88,1,0.2,0.22,0.23),(3,0.72,0.45,0.42,0.83,1,0.83,0.98,0.91,0.38,0.28,0.11),(4,0.75,0.48,0.27,0.36,0.27,0.51,0.73,0.77,0.39,0.26,0.19),(5,0.46,0.41,0.34,0.25,0.73,0.39,0.66,0.44,0.73,0.37,0.73),(6,0.86,0.7,0.58,0.35,1,0.44,0.88,0.67,0.98,0.64,0.27),(7,0.15,0.57,0.83,0.42,0.84,0.82,0.64,0.8,0.82,0.82,0.47),(8,0.81,0.86,0.5,0.6,0.23,0.41,0.65,0.69,0.8,0.16,0.56),(9,0.99,0.1,0.37,0.33,0.87,0.26,0.44,0.53,0.56,0.99,0.82),(10,0.84,0.37,0.65,0.6,0.46,0.65,0.24,0.7,0.45,0.7,0.18);
/*!40000 ALTER TABLE `audio_features` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `available_market`
--

DROP TABLE IF EXISTS `available_market`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `available_market` (
  `market_id` int NOT NULL AUTO_INCREMENT,
  `market_code` varchar(2) DEFAULT NULL,
  `market_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`market_id`),
  UNIQUE KEY `market_code` (`market_code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `available_market`
--

LOCK TABLES `available_market` WRITE;
/*!40000 ALTER TABLE `available_market` DISABLE KEYS */;
INSERT INTO `available_market` VALUES (1,'US','United States'),(2,'UK','United Kingdom'),(3,'IN','India');
/*!40000 ALTER TABLE `available_market` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `band`
--

DROP TABLE IF EXISTS `band`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `band` (
  `band_id` int NOT NULL AUTO_INCREMENT,
  `band_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`band_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `band`
--

LOCK TABLES `band` WRITE;
/*!40000 ALTER TABLE `band` DISABLE KEYS */;
INSERT INTO `band` VALUES (1,'The Lumineers');
/*!40000 ALTER TABLE `band` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `band_artist`
--

DROP TABLE IF EXISTS `band_artist`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `band_artist` (
  `band_id` int NOT NULL,
  `artist_id` int NOT NULL,
  PRIMARY KEY (`band_id`,`artist_id`),
  KEY `artist_id` (`artist_id`),
  CONSTRAINT `band_artist_ibfk_1` FOREIGN KEY (`band_id`) REFERENCES `band` (`band_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `band_artist_ibfk_2` FOREIGN KEY (`artist_id`) REFERENCES `artist` (`artist_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `band_artist`
--

LOCK TABLES `band_artist` WRITE;
/*!40000 ALTER TABLE `band_artist` DISABLE KEYS */;
INSERT INTO `band_artist` VALUES (1,1),(1,2),(1,3),(1,4),(1,5);
/*!40000 ALTER TABLE `band_artist` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `country_code`
--

DROP TABLE IF EXISTS `country_code`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `country_code` (
  `country_name` varchar(300) NOT NULL,
  `numeric_code` int DEFAULT NULL,
  PRIMARY KEY (`country_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `country_code`
--

LOCK TABLES `country_code` WRITE;
/*!40000 ALTER TABLE `country_code` DISABLE KEYS */;
INSERT INTO `country_code` VALUES ('Afghanistan',93),('Albania',355),('Algeria',213),('American Samoa',1684),('Andorra',376),('Angola',244),('Anguilla',1264),('Antarctica',672),('Antigua and Barbuda',1268),('Argentina',54),('Armenia',374),('Aruba',297),('Australia',61),('Austria',43),('Azerbaijan',994),('Bahamas',1242),('Bahrain',973),('Bangladesh',880),('Barbados',1246),('Belarus',375),('Belgium',32),('Belize',501),('Benin',229),('Bermuda',1441),('Bhutan',975),('Bolivia',591),('Bosnia and Herzegovina',387),('Botswana',267),('Brazil',55),('British Indian Ocean Territory',246),('British Virgin Islands',1284),('Brunei',673),('Bulgaria',359),('Burkina Faso',226),('Burundi',257),('Cambodia',855),('Cameroon',237),('Canada',1),('Cape Verde',238),('Cayman Islands',1345),('Central African Republic',236),('Chad',235),('Chile',56),('China',86),('Christmas Island',61),('Cocos Islands',61),('Colombia',57),('Comoros',269),('Cook Islands',682),('Costa Rica',506),('Croatia',385),('Cuba',53),('Curacao',599),('Cyprus',357),('Czech Republic',420),('Democratic Republic of the Congo',243),('Denmark',45),('Djibouti',253),('Dominica',1767),('Dominican Republic',1809),('East Timor',670),('Ecuador',593),('Egypt',20),('El Salvador',503),('Equatorial Guinea',240),('Eritrea',291),('Estonia',372),('Ethiopia',251),('Falkland Islands',500),('Faroe Islands',298),('Fiji',679),('Finland',358),('France',33),('French Polynesia',689),('Gabon',241),('Gambia',220),('Georgia',995),('Germany',49),('Ghana',233),('Gibraltar',350),('Greece',30),('Greenland',299),('Grenada',1473),('Guam',1671),('Guatemala',502),('Guernsey',441481),('Guinea',224),('Guinea-Bissau',245),('Guyana',592),('Haiti',509),('Honduras',504),('Hong Kong',852),('Hungary',36),('Iceland',354),('India',91),('Indonesia',62),('Iran',98),('Iraq',964),('Ireland',353),('Isle of Man',441624),('Israel',972),('Italy',39),('Ivory Coast',225),('Jamaica',1876),('Japan',81),('Jersey',441534),('Jordan',962),('Kazakhstan',7),('Kenya',254),('Kiribati',686),('Kosovo',383),('Kuwait',965),('Kyrgyzstan',996),('Laos',856),('Latvia',371),('Lebanon',961),('Lesotho',266),('Liberia',231),('Libya',218),('Liechtenstein',423),('Lithuania',370),('Luxembourg',352),('Macau',853),('Macedonia',389),('Madagascar',261),('Malawi',265),('Malaysia',60),('Maldives',960),('Mali',223),('Malta',356),('Marshall Islands',692),('Mauritania',222),('Mauritius',230),('Mayotte',262),('Mexico',52),('Micronesia',691),('Moldova',373),('Monaco',377),('Mongolia',976),('Montenegro',382),('Montserrat',1664),('Morocco',212),('Mozambique',258),('Myanmar',95),('Namibia',264),('Nauru',674),('Nepal',977),('Netherlands',31),('Netherlands Antilles',599),('New Caledonia',687),('New Zealand',64),('Nicaragua',505),('Niger',227),('Nigeria',234),('Niue',683),('North Korea',850),('Northern Mariana Islands',1670),('Norway',47),('Oman',968),('Pakistan',92),('Palau',680),('Palestine',970),('Panama',507),('Papua New Guinea',675),('Paraguay',595),('Peru',51),('Philippines',63),('Pitcairn',64),('Poland',48),('Portugal',351),('Puerto Rico',1787),('Qatar',974),('Republic of the Congo',242),('Reunion',262),('Romania',40),('Russia',7),('Rwanda',250),('Saint Barthelemy',590),('Saint Helena',290),('Saint Kitts and Nevis',1869),('Saint Lucia',1758),('Saint Martin',590),('Saint Pierre and Miquelon',508),('Saint Vincent and the Grenadines',1784),('Samoa',685),('San Marino',378),('Sao Tome and Principe',239),('Saudi Arabia',966),('Senegal',221),('Serbia',381),('Seychelles',248),('Sierra Leone',232),('Singapore',65),('Sint Maarten',1721),('Slovakia',421),('Slovenia',386),('Solomon Islands',677),('Somalia',252),('South Africa',27),('South Korea',82),('South Sudan',211),('Spain',34),('Sri Lanka',94),('Sudan',249),('Suriname',597),('Svalbard and Jan Mayen',47),('Swaziland',268),('Sweden',46),('Switzerland',41),('Syria',963),('Taiwan',886),('Tajikistan',992),('Tanzania',255),('Thailand',66),('Togo',228),('Tokelau',690),('Tonga',676),('Trinidad and Tobago',1868),('Tunisia',216),('Turkey',90),('Turkmenistan',993),('Turks and Caicos Islands',1649),('Tuvalu',688),('U.S. Virgin Islands',1340),('Uganda',256),('Ukraine',380),('United Arab Emirates',971),('United Kingdom',44),('United States',1),('Uruguay',598),('Uzbekistan',998),('Vanuatu',678),('Vatican',379),('Venezuela',58),('Vietnam',84),('Wallis and Futuna',681),('Western Sahara',212),('Yemen',967),('Zambia',260),('Zimbabwe',263);
/*!40000 ALTER TABLE `country_code` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `first_name` varchar(300) DEFAULT NULL,
  `last_name` varchar(300) DEFAULT NULL,
  `gender` varchar(300) DEFAULT NULL,
  `date_of_birth` date DEFAULT NULL,
  `address_id` int DEFAULT NULL,
  `phone_no` varchar(300) DEFAULT NULL,
  `password` varchar(300) DEFAULT NULL,
  `email_address` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `phone_no` (`phone_no`),
  UNIQUE KEY `email_address` (`email_address`),
  KEY `address_id` (`address_id`),
  CONSTRAINT `customer_ibfk_1` FOREIGN KEY (`address_id`) REFERENCES `address` (`address_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `genre`
--

DROP TABLE IF EXISTS `genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `genre` (
  `genre_id` int NOT NULL,
  `genre_title` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`genre_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `genre`
--

LOCK TABLES `genre` WRITE;
/*!40000 ALTER TABLE `genre` DISABLE KEYS */;
INSERT INTO `genre` VALUES (1,'Rock'),(2,'Pop music'),(3,'Popular music'),(4,'Hip hop music'),(5,'Rhythm and blues'),(6,'Country music'),(7,'Folk music'),(8,'Jazz'),(9,'Classical music'),(10,'Blues'),(11,'Electronic music'),(12,'Musical theatre'),(13,'Heavy metal'),(14,'Electronic dance music'),(15,'Punk rock'),(16,'Alternative rock'),(17,'Dance music'),(18,'World music'),(19,'Soul music'),(20,'Music of the United States'),(21,'Funk'),(22,'Indie rock'),(23,'Singing'),(24,'Pop rock'),(25,'Reggae'),(26,'Techno'),(27,'Latin music'),(28,'Contemporary R&amp;B'),(29,'House music'),(30,'Dubstep'),(31,'Easy listening'),(32,'New-age music'),(33,'Rapping'),(34,'Rock and roll'),(35,'Experimental music'),(36,'New wave'),(37,'Instrumental'),(38,'Disco'),(39,'Music of Latin America'),(40,'Electronica'),(41,'Jazz fusion'),(42,'Ambient music'),(43,'Musical'),(44,'Ska'),(45,'Progressive rock'),(46,'Hardcore punk'),(47,'Bluegrass'),(48,'Art music'),(49,'Electro'),(50,'Gospel music'),(51,'Soundtrack');
/*!40000 ALTER TABLE `genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `languages`
--

DROP TABLE IF EXISTS `languages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `languages` (
  `language_id` int NOT NULL,
  `language_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`language_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `languages`
--

LOCK TABLES `languages` WRITE;
/*!40000 ALTER TABLE `languages` DISABLE KEYS */;
INSERT INTO `languages` VALUES (1,'English'),(2,'Spanish');
/*!40000 ALTER TABLE `languages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `proficiency`
--

DROP TABLE IF EXISTS `proficiency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `proficiency` (
  `proficiency_id` int NOT NULL,
  `proficiency_name` varchar(300) DEFAULT NULL,
  PRIMARY KEY (`proficiency_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `proficiency`
--

LOCK TABLES `proficiency` WRITE;
/*!40000 ALTER TABLE `proficiency` DISABLE KEYS */;
INSERT INTO `proficiency` VALUES (1,'Vocal'),(2,'Acoustic Guitar'),(3,'Electric Guitar'),(4,'Bass Guitar'),(5,'Piano'),(6,'Chello'),(7,'Violin'),(8,'Drums'),(9,'Flute');
/*!40000 ALTER TABLE `proficiency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `track`
--

DROP TABLE IF EXISTS `track`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track` (
  `track_id` int NOT NULL AUTO_INCREMENT,
  `track_no` int DEFAULT NULL,
  `track_title` varchar(300) DEFAULT NULL,
  `track_release_date` datetime DEFAULT NULL,
  `language_id` int DEFAULT NULL,
  `track_price` int DEFAULT NULL,
  `duration_ms` int DEFAULT NULL,
  `explicit` tinyint(1) DEFAULT NULL,
  `track_icon` varchar(1000) DEFAULT NULL,
  PRIMARY KEY (`track_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track`
--

LOCK TABLES `track` WRITE;
/*!40000 ALTER TABLE `track` DISABLE KEYS */;
INSERT INTO `track` VALUES (1,1,'Donna','2019-05-05 00:00:00',1,5,183000,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(2,2,'Life In The City','2019-05-06 00:00:00',1,5,210600,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(3,3,'Gloria','2019-05-07 00:00:00',1,5,201600,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(4,4,'It Wasn\'t Easy To Be Happy For You','2019-05-08 00:00:00',1,5,200400,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(5,5,'Leader Of The Landslide','2019-05-09 00:00:00',1,5,332400,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(6,6,'Left For Denver','2019-05-10 00:00:00',1,5,189600,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(7,7,'My Cell','2019-05-11 00:00:00',1,5,189600,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(8,8,'Jimmy Sparks','2019-05-12 00:00:00',1,5,333000,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(9,9,'April','2019-05-13 00:00:00',1,5,30000,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png'),(10,10,'Salt And The Sea','2019-05-14 00:00:00',1,5,258000,1,'https://upload.wikimedia.org/wikipedia/en/5/54/The_Lumineers_-_III.png');
/*!40000 ALTER TABLE `track` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `track_band`
--

DROP TABLE IF EXISTS `track_band`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track_band` (
  `track_id` int NOT NULL,
  `band_id` int NOT NULL,
  PRIMARY KEY (`track_id`,`band_id`),
  KEY `band_id` (`band_id`),
  CONSTRAINT `track_band_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `track` (`track_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `track_band_ibfk_2` FOREIGN KEY (`band_id`) REFERENCES `band` (`band_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track_band`
--

LOCK TABLES `track_band` WRITE;
/*!40000 ALTER TABLE `track_band` DISABLE KEYS */;
INSERT INTO `track_band` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1);
/*!40000 ALTER TABLE `track_band` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `track_genre`
--

DROP TABLE IF EXISTS `track_genre`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track_genre` (
  `track_id` int NOT NULL,
  `genre_id` int NOT NULL,
  PRIMARY KEY (`track_id`,`genre_id`),
  KEY `genre_id` (`genre_id`),
  CONSTRAINT `track_genre_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `track` (`track_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `track_genre_ibfk_2` FOREIGN KEY (`genre_id`) REFERENCES `genre` (`genre_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track_genre`
--

LOCK TABLES `track_genre` WRITE;
/*!40000 ALTER TABLE `track_genre` DISABLE KEYS */;
INSERT INTO `track_genre` VALUES (1,6),(2,6),(3,6),(4,6),(5,6),(6,6),(7,6),(8,6),(9,6),(10,6),(1,7),(2,7),(3,7),(4,7),(5,7),(6,7),(7,7),(8,7),(9,7),(10,7),(3,10),(9,37);
/*!40000 ALTER TABLE `track_genre` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `track_market`
--

DROP TABLE IF EXISTS `track_market`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `track_market` (
  `track_id` int NOT NULL,
  `market_id` int NOT NULL,
  PRIMARY KEY (`track_id`,`market_id`),
  KEY `market_id` (`market_id`),
  CONSTRAINT `track_market_ibfk_1` FOREIGN KEY (`track_id`) REFERENCES `track` (`track_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `track_market_ibfk_2` FOREIGN KEY (`market_id`) REFERENCES `available_market` (`market_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `track_market`
--

LOCK TABLES `track_market` WRITE;
/*!40000 ALTER TABLE `track_market` DISABLE KEYS */;
INSERT INTO `track_market` VALUES (1,1),(2,1),(3,1),(4,1),(5,1),(6,1),(7,1),(8,1),(9,1),(10,1),(1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(1,3),(2,3),(3,3),(4,3),(5,3),(6,3),(7,3),(8,3),(9,3),(10,3);
/*!40000 ALTER TABLE `track_market` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'playyn'
--

--
-- Dumping routines for database 'playyn'
--
/*!50003 DROP FUNCTION IF EXISTS `millis_to_duration` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `millis_to_duration`(mil int) RETURNS varchar(300) CHARSET utf8mb4
    DETERMINISTIC
begin
    declare f varchar(300);
    if (mil > 3599999) then
		set f = "%H:%i:%s";
	else
		set f = "%i:%s";
	end if;
    return time_format(sec_to_time(mil/1000), f);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP FUNCTION IF EXISTS `time_since_release` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` FUNCTION `time_since_release`(r_date date) RETURNS varchar(300) CHARSET utf8mb4
    DETERMINISTIC
begin
    declare f varchar(300);
    declare days varchar(300);
    set days = datediff(curdate(), r_date);
    if (days > 7 and days <= 28) then
		set f = concat((days div 7), " weeks ago");
	elseif (days > 28 and days <= 360) then
		set f = concat((days div 30), " months ago");
	else
		set f = concat((days div 360), " years ago");
	end if;
    return f;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `fetch_user_profile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `fetch_user_profile`(in r varchar(30),
									in e_mail varchar(300))
begin
	if (r = 'customer') then
		select * from customer natural join address where email_address = e_mail;
	elseif (r = 'artist') then
		select * from artist natural join address where email_address = e_mail;
	end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_addresses` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_addresses`()
begin
	select * from address;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_albums` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_albums`()
begin
	select album_name,
		time_since_release(album_release_date) as album_release,
		album_icon, band_name, count(track_id) as track_count
    from album
    natural join album_band 
    natural join band 
    natural join album_track;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_artists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_artists`()
begin
	select concat(first_name, " ", last_name) as name, gender, 
		trim(leading '0' from (date_format(from_days(datediff(curdate(), date_of_birth)), "%Y"))) as age,
		concat(city, ", ", state, ", ", country) as current_city, phone_no, email_address,
		ifnull(band_name, "") as band_name
    from artist
    natural join address
    left join band_artist
    using (artist_id)
    left join band
    using (band_id);
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_available_artists` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_available_artists`(in a_id int)
begin
	select *
    from artist
    where artist_id
    not in
    (select artist_id from band_artist)
    and
    artist_id != a_id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_country_codes` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_country_codes`()
begin
	select country_name, numeric_code
    from country_code
    order by country_name;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_all_tracks` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_all_tracks`()
begin
	select track_icon, track_no, track_title,
		time_since_release(track_release_date) as track_release,
		concat("$", track_price) as track_price, millis_to_duration(duration_ms) as duration,
		language_name, album_name, band_name
    from track
    natural join languages
    natural join album_track
    natural join album
    natural join album_band
    natural join band;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_band_details` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_band_details`(in a_id int)
begin
	select band_id, band_name, 
		concat(first_name, " ", last_name) as member,
		group_concat(ifnull(proficiency_name, "")) as proficiency
    from (select band_id, band_name
			from band_artist
			natural join band
			where artist_id = a_id) as b
    natural join band_artist
    natural join artist
    left join artist_proficiency
    using (artist_id)
    left join proficiency
    using (proficiency_id)
    group by artist_id;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_featured_albums` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_featured_albums`()
begin
	select album_name, band_name,
		time_since_release(album_release_date) as album_release,
		count(*) as num_tracks, album_icon
    from album
    natural join album_band
    natural join band
    natural join album_track
    limit 6;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_featured_bands` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_featured_bands`()
begin
	select band_name, group_concat(concat(first_name, " ", last_name)) as band_members
    from band
    natural join band_artist
    natural join artist
    group by band_id
    limit 6;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `get_featured_tracks` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `get_featured_tracks`()
begin
	select track_icon, track_title,
		time_since_release(track_release_date) as track_release, 
		millis_to_duration(duration_ms) as duration, album_name, band_name
    from track
    natural join album_track
    natural join album
    natural join album_band
    natural join band
    limit 6;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!50003 DROP PROCEDURE IF EXISTS `update_user_profile` */;
/*!50003 SET @saved_cs_client      = @@character_set_client */ ;
/*!50003 SET @saved_cs_results     = @@character_set_results */ ;
/*!50003 SET @saved_col_connection = @@collation_connection */ ;
/*!50003 SET character_set_client  = utf8mb4 */ ;
/*!50003 SET character_set_results = utf8mb4 */ ;
/*!50003 SET collation_connection  = utf8mb4_0900_ai_ci */ ;
/*!50003 SET @saved_sql_mode       = @@sql_mode */ ;
/*!50003 SET sql_mode              = 'STRICT_TRANS_TABLES,NO_ENGINE_SUBSTITUTION' */ ;
DELIMITER ;;
CREATE DEFINER=`root`@`localhost` PROCEDURE `update_user_profile`(in r varchar(30),
									 in e_mail varchar(300),
                                     in f_name varchar(300),
                                     in l_name varchar(300),
                                     in g varchar(300),
                                     in dob date,
                                     in a_id int,
                                     in p_id int)
begin
	declare user_id int;
	if (r = 'customer') then
		if (f_name != '') then
			update customer set first_name = f_name where email_address = e_mail;
		end if;
        if (l_name != '') then
			update customer set last_name = l_name where email_address = e_mail;
		end if;
        if (g != '') then
			update customer set gender = g where email_address = e_mail;
		end if;
        update customer set date_of_birth = dob where email_address = e_mail;
        if (a_id != 0) then
			update customer set address_id = a_id where email_address = e_mail;
		end if;
	elseif (r = 'artist') then
		if (f_name != '') then
			update artist set first_name = f_name where email_address = e_mail;
		end if;
        if (l_name != '') then
			update artist set last_name = l_name where email_address = e_mail;
		end if;
        if (g != '') then
			update artist set gender = g where email_address = e_mail;
		end if;
        update artist set date_of_birth = dob where email_address = e_mail;
        if (a_id != 0) then
			update artist set address_id = a_id where email_address = e_mail;
		end if;
        if (p_id != '') then
			select artist_id into user_id from artist where email_address=e_mail;
			insert ignore into artist_proficiency values (user_id, p_id);
		end if;
	end if;
end ;;
DELIMITER ;
/*!50003 SET sql_mode              = @saved_sql_mode */ ;
/*!50003 SET character_set_client  = @saved_cs_client */ ;
/*!50003 SET character_set_results = @saved_cs_results */ ;
/*!50003 SET collation_connection  = @saved_col_connection */ ;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-04-30 20:46:19
